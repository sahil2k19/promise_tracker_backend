// roles.js

const ROLES = {
    SUPER_ADMIN: 0,
    DEPARTMENT_HEAD: 1,
    PROJECT_LEAD: 2,
    MEMBER: 3,
  };
  
  module.exports = ROLES;

  const reportingTo = {
    SUPER_ADMIN: 0,
    DEPARTMENT_HEAD: 1,
    PROJECT_LEAD: 2,
    MEMBER: 3,
  };
  module.exports = reportingTo;
  